# Story S2 — 词库存储与限制

## 背景
词库是 mini-translate 的核心数据，需要稳定存储与上限控制，确保翻译行为与管理界面一致。

## 用户价值
- 维护可靠的个人生词表。
- 防止数据过多导致性能下降或存储失控。

## 需求要点
1. 词条 schema 参照 `docs/vocabulary-spec.md`。
2. 存储使用 `chrome.storage.local`，提供 CRUD 接口。
3. 添加词条时检测重复（原文 term 为键），去重策略明确。
4. 总条目达到 500 时阻止继续添加／导入，并返回错误信息。
5. 提供事件通知机制，供 Options 页面和 content script 同步更新。

## 验收标准
- 本地存储写入/读取稳定，重启浏览器后词库保留。
- 添加第 501 条时被拒绝并提示原因。
- 导入流程遵守上限与去重规则。
- QA 覆盖 CRUD、并发写入、上限与错误处理。

## QA Results
- Gate: PASS — chrome.storage 存取、500 条上限、词条去重与 VOCAB_UPDATED 事件均已实现，背景脚本与 Options/UI 同步正常。
- Tests: `npm run validate`
- Notes: 单测模拟存储上下文验证上限、删除、页面状态切换；建议在真实 Chrome 环境复测 session storage 行为。
